package com.msmith.bottomnavigation

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.fragment_bottom_main.*
import java.lang.Thread.sleep


class bottomMainFragment : Fragment() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_bottom_main, container, false)



    }



    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        /*for (i in 1..3) {
            if (i.equals(1)) {
                imageView.setImageResource(R.drawable.image1)
                sleep(3000)
            }
            else if ( i.equals(2))
            {
                imageView.setImageResource(R.drawable.image2)
                sleep(3000)
            }else if ( i.equals(3))
            {
                imageView.setImageResource(R.drawable.image3)
                sleep(3000)
            }

        }
*/
        //SlideShow()
    }

    //Simple companion object
    companion object{
        private var instance : bottomMainFragment? = null
        fun getInstance() : bottomMainFragment
        {
            return instance!!

        }
    }

    fun SlideShow()
    {

        while(true) {
            imageView.setImageResource(R.drawable.image1)
            sleep(3000)
            imageView.setImageResource(R.drawable.image2)
            sleep(3000)
            imageView.setImageResource(R.drawable.image3)
            sleep(3000)
        }
    }
}


