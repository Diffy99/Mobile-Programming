package com.msmith.bottomnavigation

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.navigation.Navigation
import kotlinx.android.synthetic.main.fragment_bottom_second.*


var newChannelCallLetters:  EditText? = null
var newChannel_URL: EditText? = null

class bottomSecondFragment : Fragment()
{

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        instance = this

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View?
    {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_bottom_second, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?)
    {
        super.onViewCreated(view, savedInstanceState)

        var handler = ModifyHandler()
        SubmitChannelButton.setOnClickListener(handler)


    }

    companion object
    {
        private var instance : bottomSecondFragment? = null
        public fun getInstance() : bottomSecondFragment
        {
            return instance!!
        }
    }
    class ModifyHandler : View.OnClickListener {
        override fun onClick(v: View?) {

            if (v != null) {
               var calls = getInstance().insertLettersBar.text.toString()
                var urls = getInstance().insertURLBar.text.toString()

                println(calls + "______________________________________________")
                println(urls + "_______________________________________________")



                channelNames.add(calls)
                channelURLs.add(urls)


            }





        }
        }
}


