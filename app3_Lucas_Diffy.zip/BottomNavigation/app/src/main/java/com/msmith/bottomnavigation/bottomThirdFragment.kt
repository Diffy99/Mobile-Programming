package com.msmith.bottomnavigation

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.View.inflate
import android.view.ViewGroup
import android.widget.Button
import android.widget.Space
import kotlinx.android.synthetic.main.fragment_bottom_third.*
import kotlinx.android.synthetic.main.fragment_fourth.*


class bottomThirdFragment : Fragment()
{

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

      /*  for (i in 0..15)
        {
            var button1 = inflate(MainActivity.getInstance(), R.layout.button, null) as Button

            var text = "Button " + i
            button1.setText(text)

            var handler = FourthFragment.ButtonHandler()
            button1.setOnClickListener(handler)

            linearLayout.addView(button1)

            var space = Space(MainActivity.getInstance())
            space.minimumHeight = 15

            linearLayout.addView(space)
        }
*/
    }


    class ButtonHandler : View.OnClickListener
    {
        override fun onClick(p0: View?)
        {
            //var navController = 			Navigation.findNavController(ThirdFragment.getInstance().requireView())
            //Trkansition to 5th Fragment and send null Bundle
            //navController.navigate(R.id.thirdToFifth, null)
        }
    }



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View?
    {




        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_bottom_third, container, false)
    }



    companion object
    {
        private var instance : bottomThirdFragment? = null
        public fun getInstance() : bottomThirdFragment
        {
            return instance!!
        }
    }

}

