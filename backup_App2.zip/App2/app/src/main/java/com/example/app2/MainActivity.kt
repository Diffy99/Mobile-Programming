package com.example.app2

import android.annotation.SuppressLint
import kotlinx.android.synthetic.main.activity_main.*
import android.content.Context
import android.text.Editable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebViewClient
import kotlinx.android.synthetic.main.activity_main.*
import android.net.http.SslError
import android.webkit.SslErrorHandler
import android.webkit.WebView
import android.webkit.WebResourceResponse
import android.webkit.WebResourceRequest
import android.webkit.WebResourceError
import android.graphics.Bitmap
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import kotlin.math.absoluteValue



class MainActivity : AppCompatActivity() {



    //simple companion object
    companion object
    {
        private var instance : MainActivity? = null
        public fun getInstance() : MainActivity
        {
            return instance!!
        }
    }


    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        instance = this

        //Instantiate Handler
        var handler = Handler()



        //Add the Code Here

        //register handler with the buttons/widgets
        seekBar2.setOnSeekBarChangeListener(handler)
        switch1.setOnCheckedChangeListener(handler)
        switch1.setOnClickListener(handler)
        button.setOnClickListener(handler)

        //create the web view needed to stream the audio
        var webDelegate = Delegate()

        webView.webViewClient = webDelegate

        //this will allow the tracing of links
        webView.settings.javaScriptEnabled = true
        webView.settings.javaScriptCanOpenWindowsAutomatically = true

        //webView.loadUrl("http://www.youtube.com")











    }




}

class Handler : View.OnClickListener, CompoundButton.OnCheckedChangeListener,
    SeekBar.OnSeekBarChangeListener,
    TextView.OnEditorActionListener, TextWatcher
{
    //set a global frequency variable, 0 for AM, and 1 for FM
// Depending on what is selected, the listeners will check for this value and as such alter
// the seekbar as appropriate so that a near value can be found for each station
    private var freq = 0;


    private var WebView: WebView = MainActivity.getInstance().findViewById<WebView>(R.id.webView)
    private var imageView: ImageView = MainActivity.getInstance().findViewById<ImageView>(R.id.imageView)
    private var context = imageView.context


    private var selectedStation = ""
    private var selectedBand = "AM" // by default the apps starts on AM

    private var amArray = arrayOf<Int>(660, 790, 820, 890, 920)
    private var amIcons = arrayOf<String>("wfan","kabc","wbap","wls", "karnam")

    private var fmArray = arrayOf<Double>(97.1, 98.5, 98.9, 99.7, 101.9, 102.9, 107.7)
    private var fmIcons = arrayOf<String>("wxyt", "kurb", "wkim", "wwtn", "kdxe", "karnfm", "klal")




    override fun afterTextChanged(s: Editable?)
    {
        println(s)
    }
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int)
    {
        println(s)
    }
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int)
    {
        println(s)
    }


    //Activated by pressing return on the virtual keyboard
    override fun onEditorAction(v: TextView?, actionId: Int, event: KeyEvent?): Boolean
    {
        println(v?.text)
        var im = MainActivity.getInstance().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

        im.hideSoftInputFromWindow(v?.windowToken,0)
        return true // Stop event Handling if false is returned, true allows other events to process...
    }


    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean)
    {
        var e = 0
        // Very roundabout way of doing this but one of the only ways I know how to tackle this at this point
        // set the freq depending on the value of the freq variable, set the range of the seekbar.
        // So if the frequency is equal to 1, we take the original bar of 30 and add 83 to it to get a normal
        // range for fm frequencies
        if(freq == 1) {
            seekBar?.max = 30
            e = (progress.plus(83))
        }else if (freq == 0) {
            seekBar?.max = 700
             e = (progress.plus(520))    // ranges start at near 620 on the scale, add 400 to anything between 0-1100
        }

        var defaultIcon_ = MainActivity.getInstance().resources.getIdentifier("launch", "drawable", context.packageName)

        imageView.setImageResource(defaultIcon_)

        var currentStation = MainActivity.getInstance().findViewById<TextView>(R.id.station)
        var text = e.toDouble().toString()
        currentStation.text = text
    }

    override fun onStartTrackingTouch(seekBar: SeekBar?)
    {
        selectedStation = ""
        println("start")
        var currentStation = MainActivity.getInstance().findViewById<TextView>(R.id.station)
        var text = "Now Playing"
        currentStation.text = text
        var defaultIcon_ = MainActivity.getInstance().resources.getIdentifier("launch", "drawable", context.packageName)

        imageView.setImageResource(defaultIcon_)
    }

    override fun onStopTrackingTouch(seekBar: SeekBar?)
    {
        var text = ""
        var amdifference = 100
        var fmDifference = 100.0
        var defaultIcon = MainActivity.getInstance().resources.getIdentifier("launch", "drawable", context.packageName)

        imageView.setImageResource(defaultIcon)

        println("stop")
        var currentStation = MainActivity.getInstance().findViewById<TextView>(R.id.station)

         if(freq == 0)
        {
           text = seekBar?.progress?.plus(520).toString()
            for(I in amArray)
            {
                if (seekBar != null) {
                    if(I.minus(text.toDouble()).absoluteValue < amdifference) {
                        amdifference = I.minus(text.toDouble()).absoluteValue.toInt()
                        if (amdifference <= 1.0) {
                            text = I.toString()
                            var aIcon = amIcons[amArray.indexOf(I)]
                            var id = MainActivity.getInstance().resources.getIdentifier(aIcon, "drawable", context.packageName)
                            imageView.setImageResource(id)
                            currentStation.text = aIcon.toUpperCase()
                            selectedStation = aIcon.toUpperCase()

                        }
                    }

                }
            }

        }else if (freq == 1) {
             text = seekBar?.progress?.toDouble()?.plus(83).toString()
             var originalProgress = text
             var ogDifference = 10.0 // setting this up so that when it is changed by the first value that is < .5 difference, it would require a difference smaller than the original to take over.
             for (I in fmArray) {
                 if (seekBar != null) {
                     if (I.minus(text.toDouble()).absoluteValue < fmDifference ) {
                         fmDifference = I.minus(text.toDouble()).absoluteValue



                         //What occurs below is convoluted but simplistic at the same time, at least in my own opinion
                         /*
                         *      What occurs is that, since fmDifference will base off of the text object, not necessarily what is
                         *      put on the slider itself, what must occur is a secondhand safegaurd to make sure that stations within
                         *      the same whole number range will not override each other/ erase a station
                         *
                         *      so in order for that to occur, i made sure that each station is tested, if they are within .5 of the
                         *      value of the currently selected value AND they closer than the original difference they only then can be assumed
                         *      to be the actual closest.
                         *
                         *      i.e.
                         *          if i set slider on 98, it will go through the stations array until it reaches 98.5,
                         *          98.5 is within .5 of 98, and since there has been no previous channel to do so,
                         *          it will be the assigned value of text at this occurance.
                         *
                         *          so now that text == 98.5, 98.9 is within the .5 range from text.
                         *          however due to the second check of the originalDifference
                         *            98.9 - 98 = .9, .9 is not < .5 and so it is not overriden and 98.5 remains the selected station
                         *
                         *      i.e 2
                         *          if i set the slider on 99, it will go through until it reaches 98.5,
                         *          98.5 is within .5 of 99, and will be assigned due to no previous assignments
                         *
                         *          so now it goes forward to 98.9, which is within the range of .5.
                         *          and since |98.9 - 99.0| = .1, which is lower than |98.5 - 99.0 | = .5
                         *          98.8 takes the place of 98.5 in the text variable, and is assigned properly
                         * */
                         if (fmDifference <= .5 &&  originalProgress.toDouble().minus(I).absoluteValue < ogDifference) {
                             text = I.toString()
                             var fIcon = fmIcons[fmArray.indexOf(I)]
                             var id = MainActivity.getInstance().resources.getIdentifier(fIcon, "drawable", context.packageName)
                             imageView.setImageResource(id)
                             currentStation.text = fIcon.toUpperCase()
                             ogDifference = fmDifference
                             selectedStation=fIcon.toUpperCase()
                         }
                             fmDifference = 100.0 // sets it back to normal and sees if there is a closer station, since stations in order,
                                                    // this is a safeguard for 98.8 to take over and block 98.5


                     }

                 }
             }
         }
    }


    override fun onClick(v: View?)
    {
        //Get the text – note the typecase to more specific
        var text = (v as Button).text //must typecast as base as substitute
        println("_______________________________________________________________________________________________")
        WebView.loadUrl("http://playerservices.streamtheworld.com/api/livestream-redirect/$selectedStation$selectedBand.mp3")
                //"http://playerservices.streamtheworld.com/api/livestream-redirect/"+ selectedStation + "AM.mp3"


    }

    override fun onCheckedChanged(p0: CompoundButton?, p1: Boolean)
    {
        var text = p0?.text
        println("Is checked" + p0?.isChecked)
        println(text)
        if (text == "AM")
        {
            freq = 1
            selectedBand = "FM"
            p0?.text = "FM"
        }
        else
        {
            freq = 0
            selectedBand = "AM"
            p0?.text = "AM"
        }

    }}


class Delegate : WebViewClient()
{
    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?)
    {
        super.onPageStarted(view, url, favicon)
        println("started")
    }
    override fun onPageFinished(view: WebView, url: String)
    {
        super.onPageFinished(view,url)
        println("finish")
    }
    override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError)
    {
        println(error.description )
    }
    override fun onReceivedHttpError(
        view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse
    )
    {
        println(errorResponse.data)
    }
    override fun onReceivedSslError(
        view: WebView, handler: SslErrorHandler,
        error: SslError
    )
    {
        println(error.primaryError)
    }
}

